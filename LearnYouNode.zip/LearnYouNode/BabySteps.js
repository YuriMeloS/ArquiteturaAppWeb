let soma=0;
let array = process.argv;

for (let i = 2; i < array.length; i++) {
    soma += Number(array[i]);
}

console.log(soma);