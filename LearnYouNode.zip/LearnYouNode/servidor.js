const express = require('express')
const app = express()

app.get('/', (req, res) => {
    res.send('Hello Word!')
})

const servidor = app.listen(3000, () => {
    const host = servidor.address().address
    const port = servidor.address().port

    console.log(`Listening at http://${host}:${port}`)
}) 